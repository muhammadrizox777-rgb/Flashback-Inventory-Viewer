package uz.flashbackinventory;

/** Bitta slotdagi buyum holati. */
public record Snap(String id, int count, int damage) {
    /** Player.inventoryMenu slotlari: 0 natija, 1-4 craft, 5-8 zirh, 9-35 asosiy, 36-44 hotbar, 45 offhand. */
    public static final int SLOTS = 46;
}
