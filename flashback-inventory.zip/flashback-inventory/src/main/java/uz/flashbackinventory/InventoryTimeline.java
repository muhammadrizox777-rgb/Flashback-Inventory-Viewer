package uz.flashbackinventory;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** .jsonl faylni o'qib, istalgan tick uchun GUI holatini qaytaradi. */
public final class InventoryTimeline {
    public record Entry(long tick, Snap[] slots, int sel, boolean screenOpen, double mx, double my, Snap carried) {}

    private static final Entry EMPTY = new Entry(0, new Snap[Snap.SLOTS], 0, false, 0, 0, null);

    private final List<Entry> entries = new ArrayList<>();
    public final String name;

    private InventoryTimeline(String name) { this.name = name; }

    private static Snap parse(JsonElement v) {
        if (v == null || v.isJsonNull()) return null;
        JsonArray a = v.getAsJsonArray();
        return new Snap(a.get(0).getAsString(), a.get(1).getAsInt(), a.get(2).getAsInt());
    }

    public static InventoryTimeline load(Path file) throws IOException {
        InventoryTimeline t = new InventoryTimeline(file.getFileName().toString());
        Snap[] cur = new Snap[Snap.SLOTS];
        try (BufferedReader r = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            String line;
            while ((line = r.readLine()) != null) {
                if (line.isBlank()) continue;
                JsonObject o = JsonParser.parseString(line).getAsJsonObject();
                for (Map.Entry<String, JsonElement> e : o.getAsJsonObject("s").entrySet()) {
                    int slot = Integer.parseInt(e.getKey());
                    if (slot >= 0 && slot < Snap.SLOTS) cur[slot] = parse(e.getValue());
                }
                t.entries.add(new Entry(
                    o.get("t").getAsLong(), cur.clone(), o.get("sel").getAsInt(),
                    o.get("scr").getAsInt() == 1, o.get("mx").getAsDouble(), o.get("my").getAsDouble(),
                    parse(o.get("cur"))));
            }
        }
        return t;
    }

    public long length() { return entries.isEmpty() ? 0 : entries.get(entries.size() - 1).tick(); }

    public Entry at(long tick) {
        int lo = 0, hi = entries.size() - 1, res = -1;
        while (lo <= hi) {
            int mid = (lo + hi) >>> 1;
            if (entries.get(mid).tick() <= tick) { res = mid; lo = mid + 1; } else hi = mid - 1;
        }
        return res < 0 ? EMPTY : entries.get(res);
    }
}
