package uz.flashbackinventory;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;
import java.util.stream.Stream;

/** Replay paytida o'yinchining inventar oynasini qayta chizadi (original tekstura, buyumlar, kursor). */
public final class InventoryHud {
    private static final ResourceLocation TEX =
        ResourceLocation.withDefaultNamespace("textures/gui/container/inventory.png");
    private static final int W = 176, H = 166;

    private static InventoryTimeline timeline;
    private static boolean visible, playing;
    private static long manualTick;

    private InventoryHud() {}

    public static void toggleViewer() {
        if (visible) { visible = false; return; }
        try (Stream<Path> files = Files.list(InventoryRecorder.dir())) {
            Path latest = files.filter(f -> f.toString().endsWith(".jsonl"))
                .max(Comparator.comparing(f -> f.getFileName().toString())).orElse(null);
            if (latest == null) { FlashbackInventoryClient.msg("Yozuv topilmadi"); return; }
            timeline = InventoryTimeline.load(latest);
            manualTick = 0; playing = false; visible = true;
            FlashbackInventoryClient.msg("Yuklandi: " + timeline.name);
        } catch (IOException e) {
            FlashbackInventoryClient.msg("Yuklab bo'lmadi (yozuvlar papkasi yo'q)");
        }
    }

    public static void togglePlay() { playing = !playing; }
    public static void step(long d) { manualTick = Math.max(0, manualTick + d); }
    public static void onTick() { if (visible && playing && !FlashbackBridge.hasTickHook()) manualTick++; }

    private static long currentTick() {
        if (FlashbackBridge.hasTickHook()) {
            long t = FlashbackBridge.replayTick();
            if (t >= 0) return t;
        }
        return manualTick;
    }

    // Slot koordinatalari (inventar tekstura ichida)
    private static int[] slotPos(int i) {
        if (i == 0) return new int[]{154, 28};                                   // craft natijasi
        if (i <= 4) return new int[]{98 + ((i - 1) % 2) * 18, 18 + ((i - 1) / 2) * 18}; // craft 2x2
        if (i <= 8) return new int[]{8, 8 + (i - 5) * 18};                       // zirh (bosh -> oyoq)
        if (i <= 35) return new int[]{8 + ((i - 9) % 9) * 18, 84 + ((i - 9) / 9) * 18};
        if (i <= 44) return new int[]{8 + (i - 36) * 18, 142};                   // hotbar
        return new int[]{77, 62};                                                // offhand
    }

    public static void render(GuiGraphics g, DeltaTracker dt) {
        if (!visible || timeline == null) return;
        Minecraft mc = Minecraft.getInstance();
        long tick = currentTick();
        var e = timeline.at(tick);

        g.drawString(mc.font, "Inv t=" + tick + "/" + timeline.length()
            + (FlashbackBridge.hasTickHook() ? "" : " [qo'lda]"), 4, 4, 0xFFFFFF);
        if (!e.screenOpen()) return;

        int gx = (g.guiWidth() - W) / 2, gy = (g.guiHeight() - H) / 2;
        g.blit(RenderType::guiTextured, TEX, gx, gy, 0, 0, W, H, 256, 256);

        for (int i = 0; i < Snap.SLOTS; i++) {
            Snap sn = e.slots()[i];
            if (sn == null) continue;
            int[] p = slotPos(i);
            drawItem(g, mc, sn, gx + p[0], gy + p[1]);
        }

        int mx = (int) (e.mx() * g.guiWidth()), my = (int) (e.my() * g.guiHeight());
        g.pose().pushPose();
        g.pose().translate(0, 0, 300);
        if (e.carried() != null) drawItem(g, mc, e.carried(), mx - 8, my - 8);
        else g.fill(mx - 1, my - 1, mx + 2, my + 2, 0xFFFFFFFF);
        g.pose().popPose();
    }

    private static void drawItem(GuiGraphics g, Minecraft mc, Snap sn, int x, int y) {
        ResourceLocation id = ResourceLocation.tryParse(sn.id());
        if (id == null) return;
        Item item = BuiltInRegistries.ITEM.getValue(id);
        ItemStack stack = new ItemStack(item, sn.count());
        if (sn.damage() > 0) stack.setDamageValue(sn.damage());
        g.renderItem(stack, x, y);
        g.renderItemDecorations(mc.font, stack, x, y);
    }
}
