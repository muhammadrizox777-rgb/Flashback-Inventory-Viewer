# Flashback Inventory (Fabric 1.21.4)

Flashback bilan birga o'yinchining inventar OYNASINI (slotlar, craft, kursor, qo'ldagi buyum) yozib oladi va
replay paytida o'yinchi ko'zidan ko'rayotganda original GUI ko'rinishida qayta chizadi.
Shaderlarni Iris orqali replay paytida almashtirasiz - GUI nusxasi ularning ustiga chiziladi.
Flashback kodidan FOYDALANILMAGAN (uning litsenziyasi buni taqiqlaydi) - faqat reflection orqali ulanadi.

## Yig'ish
Java 21 va Gradle 8.11+ kerak.

    gradle wrapper --gradle-version 8.12   # bir marta
    ./gradlew build                        # jar: build/libs/flashback-inventory-0.1.0.jar

Agar `fabric_version` topilmasa, gradle.properties dagi versiyani
https://fabricmc.net/develop dan 1.21.4 uchun yangilang.

## Klavishlar (Controls -> Flashback Inventory)
- K - inventar yozishni boshlash/to'xtatish (qo'lda)
- L - eng oxirgi yozuvni yuklab, inventar panelini ko'rsatish/yashirish
- J - qo'lda soat: play/pause
- , va . - 20 tick orqaga/oldinga

Yozuvlar: `.minecraft/flashback-inventory/*.jsonl`

## Flashback bilan avtomatik sinxronlash (muhim)
`config/flashback-inventory.properties`:

    recording=paket.Klass#staticMetod   # boolean: Flashback yozib olyaptimi
    replayTick=paket.Klass#staticMetod  # int/long: replay joriy tiki

Klass nomlarini Flashback jaridan toping:

    jar tf flashback-*.jar | grep -iE "record|replay"
    javap -p -cp flashback-*.jar com.moulberry.flashback.Flashback

Bo'sh qoldirsangiz, hammasi klavishlar bilan qo'lda ishlaydi.

## Hali qilinmagan
- Faqat o'yinchining oddiy inventar oynasi (E). Sandiq, pech, creative inventar va o'yinchi modeli yo'q.
- Inventar nusxasi Flashback eksport qilgan MP4 ga tushishi sinalmagan.
- Erkin kamerani o'chirish: Flashback ichki klasslariga mixin kerak (nomlar jardan aniqlanadi).
- Mod hali kompilyatsiya/sinovdan o'tkazilmagan.
