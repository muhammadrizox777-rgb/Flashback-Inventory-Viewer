package uz.flashbackinventory;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FlashbackInventoryClient implements ClientModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("flashbackinventory");
    private static final String CAT = "category.flashbackinventory";

    private static KeyMapping kRecord, kViewer, kPlay, kBack, kForward, kLock;

    @Override
    public void onInitializeClient() {
        FlashbackBridge.init();
        kRecord  = reg("record",  GLFW.GLFW_KEY_K);
        kViewer  = reg("viewer",  GLFW.GLFW_KEY_L);
        kPlay    = reg("play",    GLFW.GLFW_KEY_J);
        kBack    = reg("back",    GLFW.GLFW_KEY_COMMA);
        kForward = reg("forward", GLFW.GLFW_KEY_PERIOD);
        kLock    = reg("lock",    GLFW.GLFW_KEY_V);

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            boolean auto = FlashbackBridge.available();
            if (auto) {
                boolean rec = FlashbackBridge.isRecording();
                if (rec && !InventoryRecorder.isRecording()) InventoryRecorder.start(FlashbackBridge.recordingId());
                if (!rec && InventoryRecorder.isRecording()) InventoryRecorder.stop();
            } else {
                while (kRecord.consumeClick()) {
                    if (InventoryRecorder.isRecording()) InventoryRecorder.stop(); else InventoryRecorder.start();
                }
            }
            while (kViewer.consumeClick()) InventoryHud.toggleViewer();
            while (kLock.consumeClick()) InventoryHud.toggleLock();
            while (kPlay.consumeClick()) InventoryHud.togglePlay();
            while (kBack.consumeClick()) InventoryHud.step(-20);
            while (kForward.consumeClick()) InventoryHud.step(20);
            InventoryRecorder.onTick(mc, auto && FlashbackBridge.isRecordingPaused());
            InventoryHud.onTick();
        });

        HudRenderCallback.EVENT.register(InventoryHud::render);
    }

    private static KeyMapping reg(String name, int key) {
        return KeyBindingHelper.registerKeyBinding(
            new KeyMapping("key.flashbackinventory." + name, InputConstants.Type.KEYSYM, key, CAT));
    }

    public static void msg(String text) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) mc.player.displayClientMessage(Component.literal("[FlashbackInv] " + text), true);
        LOGGER.info(text);
    }
}
