package uz.flashbackinventory;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * Flashback bilan reflection orqali bog'lanadi (compile-time bog'liqlik YO'Q, Flashback kodi ishlatilmagan).
 * Flashback'ning ochiq nomlari: Flashback.RECORDER (static field), Flashback.isInReplay(),
 * Flashback.getReplayServer(), ReplayServer.getReplayTick()/getMetadata(), FlashbackMeta.replayIdentifier.
 * Nomlar o'zgarsa, ulanish o'chadi va mod qo'lda rejimga (K/L/J) o'tadi.
 */
public final class FlashbackBridge {
    private static boolean ready;
    private static Field recorderField;
    private static Method inReplay, getReplayServer;

    private FlashbackBridge() {}

    public static void init() {
        try {
            Class<?> fb = Class.forName("com.moulberry.flashback.Flashback");
            recorderField = fb.getField("RECORDER");
            inReplay = fb.getMethod("isInReplay");
            getReplayServer = fb.getMethod("getReplayServer");
            ready = true;
            FlashbackInventoryClient.LOGGER.info("Flashback topildi, avtomatik rejim yoqildi");
        } catch (Throwable t) {
            ready = false;
            FlashbackInventoryClient.LOGGER.warn("Flashback ulanmadi ({}), qo'lda rejim", t.toString());
        }
    }

    public static boolean available() { return ready; }

    private static Object recorder() {
        try { return recorderField.get(null); } catch (Throwable t) { return null; }
    }

    public static boolean isRecording() { return ready && recorder() != null; }

    public static boolean isRecordingPaused() {
        Object r = recorder();
        if (r == null) return false;
        try { return (Boolean) r.getClass().getMethod("isPaused").invoke(r); }
        catch (Throwable t) { return false; }
    }

    /** Yozilayotgan replayning UUID'si (yonaki fayl nomi shu bo'ladi). */
    public static String recordingId() {
        Object r = recorder();
        if (r == null) return null;
        try {
            Field f = r.getClass().getDeclaredField("metadata");
            f.setAccessible(true);
            return uuidOf(f.get(r));
        } catch (Throwable t) { return null; }
    }

    public static boolean inReplay() {
        try { return ready && (Boolean) inReplay.invoke(null); } catch (Throwable t) { return false; }
    }

    private static Object replayServer() {
        try { return getReplayServer.invoke(null); } catch (Throwable t) { return null; }
    }

    public static String replayId() {
        Object rs = replayServer();
        if (rs == null) return null;
        try { return uuidOf(rs.getClass().getMethod("getMetadata").invoke(rs)); }
        catch (Throwable t) { return null; }
    }

    public static long replayTick() {
        Object rs = replayServer();
        if (rs == null) return -1;
        try { return ((Number) rs.getClass().getMethod("getReplayTick").invoke(rs)).longValue(); }
        catch (Throwable t) { return -1; }
    }

    private static String uuidOf(Object meta) throws ReflectiveOperationException {
        return meta.getClass().getField("replayIdentifier").get(meta).toString();
    }
}
