package uz.flashbackinventory;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/**
 * Flashback bilan reflection orqali bog'lanadi (compile-time bog'liqlik yo'q).
 * Flashback'ning ichki klass nomlari ochiq API emas, shuning uchun ular
 * config/flashback-inventory.properties faylida sozlanadi:
 *   recording = paket.Klass#staticMetodNomi   -> boolean qaytaradi (yozib olinyaptimi)
 *   replayTick = paket.Klass#staticMetodNomi  -> int/long qaytaradi (replay joriy tiki)
 * Bo'sh qoldirilsa, qo'lda boshqaruv (klavishlar) ishlaydi.
 */
public final class FlashbackBridge {
    private static Method recording;
    private static Method replayTick;

    private FlashbackBridge() {}

    public static void init() {
        Path cfg = FabricLoader.getInstance().getConfigDir().resolve("flashback-inventory.properties");
        Properties p = new Properties();
        try {
            if (!Files.exists(cfg)) {
                Files.writeString(cfg,
                    "# Flashback ichki metodlari (Klass#metod). Bo'sh = qo'lda boshqaruv.\n" +
                    "recording=\nreplayTick=\n");
            }
            try (Reader r = Files.newBufferedReader(cfg)) { p.load(r); }
        } catch (IOException e) {
            FlashbackInventoryClient.LOGGER.warn("Config o'qilmadi", e);
        }
        recording = resolve(p.getProperty("recording", "").trim());
        replayTick = resolve(p.getProperty("replayTick", "").trim());
    }

    private static Method resolve(String spec) {
        if (spec.isEmpty() || !spec.contains("#")) return null;
        String[] parts = spec.split("#", 2);
        try {
            Method m = Class.forName(parts[0]).getDeclaredMethod(parts[1]);
            m.setAccessible(true);
            return m;
        } catch (Throwable t) {
            FlashbackInventoryClient.LOGGER.warn("Flashback metodi topilmadi: {}", spec);
            return null;
        }
    }

    public static boolean hasRecordingHook() { return recording != null; }
    public static boolean hasTickHook() { return replayTick != null; }

    public static boolean isRecording() {
        try { return recording != null && (Boolean) recording.invoke(null); }
        catch (Throwable t) { return false; }
    }

    public static long replayTick() {
        try { return ((Number) replayTick.invoke(null)).longValue(); }
        catch (Throwable t) { return -1; }
    }
}
