package uz.flashbackinventory;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.ItemStack;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

/**
 * Har tickda inventar GUI holatini kuzatadi, faqat o'zgarishlarni .jsonl faylga yozadi.
 * Qator: {"t":tick,"full":bool,"sel":int,"scr":0|1,"mx":0..1,"my":0..1,"cur":[id,n,d]|null,"s":{slot:[..]|null}}
 */
public final class InventoryRecorder {
    private static final int FULL_EVERY = 200;
    private static BufferedWriter writer;
    private static long tick;
    private static final Snap[] last = new Snap[Snap.SLOTS];
    private static int lastSel = -1, lastScr = -1;
    private static double lastMx = -1, lastMy = -1;
    private static Snap lastCur;
    private static boolean forceFull;

    private InventoryRecorder() {}

    public static boolean isRecording() { return writer != null; }

    public static Path dir() {
        return Minecraft.getInstance().gameDirectory.toPath().resolve("flashback-inventory");
    }

    public static void start() { start(null); }

    /** id berilsa, fayl nomi Flashback replay UUID'si bo'ladi. */
    public static void start(String id) {
        if (writer != null) return;
        try {
            Files.createDirectories(dir());
            String name = (id != null ? id : LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss"))) + ".jsonl";
            writer = Files.newBufferedWriter(dir().resolve(name), StandardCharsets.UTF_8);
            tick = 0;
            lastSel = -1; lastScr = -1; lastMx = -1; lastMy = -1; lastCur = null;
            forceFull = true;
            for (int i = 0; i < last.length; i++) last[i] = null;
            FlashbackInventoryClient.msg("Inventar yozilishi boshlandi: " + name);
        } catch (IOException e) {
            FlashbackInventoryClient.LOGGER.error("Yozishni boshlab bo'lmadi", e);
            writer = null;
        }
    }

    public static void stop() {
        if (writer == null) return;
        try { writer.close(); } catch (IOException ignored) {}
        writer = null;
        FlashbackInventoryClient.msg("Inventar yozilishi to'xtadi");
    }

    public static Snap snap(ItemStack s) {
        if (s == null || s.isEmpty()) return null;
        return new Snap(BuiltInRegistries.ITEM.getKey(s.getItem()).toString(), s.getCount(), s.getDamageValue());
    }

    public static void onTick(Minecraft mc, boolean paused) {
        if (writer == null || mc.player == null || mc.isPaused() || paused) return;
        var menu = mc.player.inventoryMenu;
        boolean full = forceFull || tick % FULL_EVERY == 0;
        boolean changed = false;

        JsonObject slots = new JsonObject();
        for (int i = 0; i < Snap.SLOTS && i < menu.slots.size(); i++) {
            Snap cur = snap(menu.getSlot(i).getItem());
            if (full || !Objects.equals(cur, last[i])) {
                slots.add(Integer.toString(i), toJson(cur));
                last[i] = cur;
                changed = true;
            }
        }

        int sel = mc.player.getInventory().selected;
        int scr = mc.screen instanceof InventoryScreen ? 1 : 0;
        double mx = 0, my = 0;
        Snap carried = null;
        if (scr == 1) {
            var w = mc.getWindow();
            mx = Math.round(mc.mouseHandler.xpos() / w.getScreenWidth() * 10000) / 10000.0;
            my = Math.round(mc.mouseHandler.ypos() / w.getScreenHeight() * 10000) / 10000.0;
            carried = snap(mc.player.containerMenu.getCarried());
        }

        if (sel != lastSel || scr != lastScr || mx != lastMx || my != lastMy
            || !Objects.equals(carried, lastCur)) {
            changed = true;
            lastSel = sel; lastScr = scr; lastMx = mx; lastMy = my; lastCur = carried;
        }

        if (changed || full) {
            JsonObject line = new JsonObject();
            line.addProperty("t", tick);
            line.addProperty("full", full);
            line.addProperty("sel", sel);
            line.addProperty("scr", scr);
            line.addProperty("mx", mx);
            line.addProperty("my", my);
            line.add("cur", toJson(carried));
            line.add("s", slots);
            try {
                writer.write(line.toString());
                writer.newLine();
            } catch (IOException e) {
                FlashbackInventoryClient.LOGGER.error("Yozishda xato", e);
                stop();
                return;
            }
            forceFull = false;
        }
        tick++;
    }

    static JsonElement toJson(Snap s) {
        if (s == null) return JsonNull.INSTANCE;
        JsonArray a = new JsonArray();
        a.add(s.id());
        a.add(s.count());
        a.add(s.damage());
        return a;
    }
}
