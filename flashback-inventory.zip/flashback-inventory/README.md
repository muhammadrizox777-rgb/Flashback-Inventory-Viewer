# Flashback Inventory (Fabric 1.21.4)

Flashback bilan birga o'yinchining inventar OYNASINI (slotlar, craft, kursor, qo'ldagi buyum) yozib oladi va
replay paytida o'yinchi ko'zidan ko'rayotganda original GUI ko'rinishida qayta chizadi.
Shaderlarni Iris orqali replay paytida almashtirasiz - GUI nusxasi ularning ustiga chiziladi.
Flashback kodidan FOYDALANILMAGAN (uning litsenziyasi buni taqiqlaydi) - faqat reflection orqali ulanadi.

## Yig'ish
Java 21 kerak. Gradle wrapper ichida bor:

    ./gradlew build        # Windows: gradlew.bat build
    # jar: build/libs/flashback-inventory-0.1.0.jar

## GitHub'da avtomatik yig'ish
Repoga shu .zip ni (yoki ochilgan fayllarni) yuklang, `.github/workflows/build.yml` mavjud bo'lsa
Actions bo'limida 'build' ishlaydi va tayyor jar 'Artifacts -> mod-jar' da chiqadi.

Agar `fabric_version` topilmasa, gradle.properties dagi versiyani
https://fabricmc.net/develop dan 1.21.4 uchun yangilang.

## Qanday ishlaydi (Flashback o'rnatilgan bo'lsa - avtomatik)
- Flashback yozishni boshlasa, mod ham inventar oynasini yozadi (pauza qilinsa, to'xtaydi). Yozuv:
  `.minecraft/flashback-inventory/<replay-UUID>.jsonl` - nomi Flashback replayining identifikatori.
- Replayni ochsangiz, mod mos yozuvni o'zi topadi va Flashback replay vaqtiga bog'lab, inventar oynasini chizadi.
- Shaderlar (Iris), resource pack'lar va MP4 eksport - Flashback'ning o'zida. Inventar nusxasi
  eksportda "no GUI" o'chiq bo'lsa videoga tushishi kutiladi (sinalmagan).
- L - inventar panelini yoqish/o'chirish.
- V - replayda kamerani yozib olgan o'yinchining ko'ziga qulflash (1-shaxs) / erkin kameraga qaytish. Standart: yoqilgan.

## Qo'lda rejim (Flashback topilmasa)
K - yozish, L - oxirgi yozuvni yuklash, J - play/pause, `,` `.` - 20 tick orqaga/oldinga.

## Hali qilinmagan
- Faqat o'yinchining oddiy inventar oynasi (E). Sandiq, pech, creative inventar va o'yinchi modeli yo'q.
- Inventar nusxasi Flashback eksport qilgan MP4 ga tushishi sinalmagan.
- 1-shaxs qulfi (V) sinalmagan; Flashback muharriridagi kamera keyframe'lari bilan to'qnashishi mumkin - kerak bo'lsa V bilan o'chiring.
- Mod hali kompilyatsiya/sinovdan o'tkazilmagan.
